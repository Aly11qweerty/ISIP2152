package com.example.okh;

public class Human {
}
